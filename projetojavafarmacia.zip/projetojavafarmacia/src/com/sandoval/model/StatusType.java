
package com.sandoval.model;


public enum StatusType {
    PENDING, APPROVED, REJECT
}
