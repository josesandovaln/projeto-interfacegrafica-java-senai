
package com.sandoval.model.dao;

import java.sql.ResultSet;
import com.sandoval.connection.ConnectionFactory;
import com.sandoval.model.beans.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class ProdutoDao {
    
    public void create(Produto produto) {
        
       Connection con = ConnectionFactory.getConnection();
       PreparedStatement stmt = null;
       
        try {
            stmt = con.prepareStatement("INSERT INTO produto (generico, comercial, fabricante, valor, consumo, tarja, quantidade)VALUES(?,?,?,?,?,?,?)");
            stmt.setString(1, produto.getGenerico());
            stmt.setString(2, produto.getComercial());
            stmt.setString(3, produto.getFabricante());
            stmt.setString(4, produto.getValor());
            stmt.setString(5, produto.getConsumo());
            stmt.setString(6, produto.getTarja());
            stmt.setString(7, produto.getQuantidade());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Cadastrado com sucesso");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar " + ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
        
    }
    
    
    public List<Produto> read(){
       
       Connection con = ConnectionFactory.getConnection();
       PreparedStatement stmt = null;
       ResultSet rs = null;
       
       List<Produto> produtos = new ArrayList<>();
       
        try {
            stmt = con.prepareStatement("SELECT * FROM produto");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Produto produto = new Produto();
                
                produto.setId(rs.getInt("id"));
                produto.setGenerico(rs.getString("generico"));
                produto.setComercial(rs.getString("comercial"));
                produto.setFabricante(rs.getString("fabricante"));
                produto.setValor(rs.getString("valor"));
                produto.setConsumo(rs.getString("consumo"));
                produto.setTarja(rs.getString("tarja"));
                produto.setQuantidade(rs.getString("quantidade"));
                produtos.add(produto);
                        
            }
            
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao listar informações" + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        
        return produtos;
       
    }
    
    public List<Produto> readForDesc(String desc){
       
       Connection con = ConnectionFactory.getConnection();
       PreparedStatement stmt = null;
       ResultSet rs = null;
       
       List<Produto> produtos = new ArrayList<>();
       
        try {
            stmt = con.prepareStatement("SELECT * FROM produto WHERE comercial LIKE ?");
            stmt.setString(1, "%" + desc + "%");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Produto produto = new Produto();
                
                produto.setId(rs.getInt("id"));
                produto.setGenerico(rs.getString("generico"));
                produto.setComercial(rs.getString("comercial"));
                produto.setFabricante(rs.getString("fabricante"));
                produto.setValor(rs.getString("valor"));
                produto.setConsumo(rs.getString("consumo"));
                produto.setTarja(rs.getString("tarja"));
                produto.setQuantidade(rs.getString("quantidade"));
                produtos.add(produto);
                        
            }
            
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao listar informações" + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        
        return produtos;
       
    }
    
}
