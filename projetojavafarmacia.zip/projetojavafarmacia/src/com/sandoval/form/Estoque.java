
package com.sandoval.form;

import com.sandoval.model.beans.Produto;
import com.sandoval.model.dao.ProdutoDao;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;


public class Estoque extends javax.swing.JPanel {

    
    public Estoque() {
        initComponents();
    }

    
    public void readJTableForDesc(String desc){
        
        DefaultTableModel modelo = (DefaultTableModel) tableEstoque.getModel();
        modelo.setNumRows(0);
        ProdutoDao pdao = new ProdutoDao();
        
        for (Produto p : pdao.readForDesc(desc)) {
            
            modelo.addRow(new Object[] {
                
                p.getComercial(),
                
                p.getQuantidade()
            });
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBorder1 = new com.sandoval.swing.PanelBorder();
        produto = new javax.swing.JLabel();
        txtProduto = new javax.swing.JTextField();
        separadorDois = new javax.swing.JSeparator();
        panelBorder3 = new com.sandoval.swing.PanelBorder();
        verificarEstoque = new javax.swing.JLabel();
        panelBorder2 = new com.sandoval.swing.PanelBorder();
        spTableFechamento = new javax.swing.JScrollPane();
        tableEstoque = new com.sandoval.swing.Table();
        titulo = new javax.swing.JLabel();

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));
        panelBorder1.setPreferredSize(new java.awt.Dimension(870, 571));

        produto.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        produto.setText("Produto");

        txtProduto.setFont(new java.awt.Font("Roboto Light", 0, 12)); // NOI18N
        txtProduto.setForeground(new java.awt.Color(204, 204, 204));
        txtProduto.setText("Nome do produto");
        txtProduto.setBorder(null);
        txtProduto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtProdutoMouseClicked(evt);
            }
        });

        separadorDois.setForeground(new java.awt.Color(153, 153, 153));

        panelBorder3.setBackground(new java.awt.Color(163, 193, 219));

        verificarEstoque.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        verificarEstoque.setForeground(new java.awt.Color(255, 255, 255));
        verificarEstoque.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        verificarEstoque.setText("VERIFICAR ESTOQUE");
        verificarEstoque.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verificarEstoque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verificarEstoqueMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelBorder3Layout = new javax.swing.GroupLayout(panelBorder3);
        panelBorder3.setLayout(panelBorder3Layout);
        panelBorder3Layout.setHorizontalGroup(
            panelBorder3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
            .addGroup(panelBorder3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder3Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(verificarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        panelBorder3Layout.setVerticalGroup(
            panelBorder3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
            .addGroup(panelBorder3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelBorder3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(verificarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        panelBorder2.setBackground(new java.awt.Color(163, 193, 219));

        spTableFechamento.setBorder(null);

        tableEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produtos", "Quantidade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        spTableFechamento.setViewportView(tableEstoque);

        javax.swing.GroupLayout panelBorder2Layout = new javax.swing.GroupLayout(panelBorder2);
        panelBorder2.setLayout(panelBorder2Layout);
        panelBorder2Layout.setHorizontalGroup(
            panelBorder2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 541, Short.MAX_VALUE)
            .addGroup(panelBorder2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelBorder2Layout.createSequentialGroup()
                    .addGap(44, 44, 44)
                    .addComponent(spTableFechamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(45, Short.MAX_VALUE)))
        );
        panelBorder2Layout.setVerticalGroup(
            panelBorder2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 206, Short.MAX_VALUE)
            .addGroup(panelBorder2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelBorder2Layout.createSequentialGroup()
                    .addGap(24, 24, 24)
                    .addComponent(spTableFechamento, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(24, Short.MAX_VALUE)))
        );

        titulo.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(127, 127, 127));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("ESTOQUE");

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGap(197, 197, 197)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(produto, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(separadorDois, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(panelBorder2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(123, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelBorder3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(titulo)
                .addGap(345, 345, 345))
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(produto)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(separadorDois, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelBorder3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(panelBorder2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, 881, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, 588, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtProdutoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtProdutoMouseClicked
        if(txtProduto.getText().equals("Nome do produto")) {
            txtProduto.setText("");
            txtProduto.setForeground(Color.black);
        }
    }//GEN-LAST:event_txtProdutoMouseClicked

    private void verificarEstoqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verificarEstoqueMouseClicked
        
        readJTableForDesc(txtProduto.getText());
        
        
        
    }//GEN-LAST:event_verificarEstoqueMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.sandoval.swing.PanelBorder panelBorder1;
    private com.sandoval.swing.PanelBorder panelBorder2;
    private com.sandoval.swing.PanelBorder panelBorder3;
    private javax.swing.JLabel produto;
    private javax.swing.JSeparator separadorDois;
    private javax.swing.JScrollPane spTableFechamento;
    private com.sandoval.swing.Table tableEstoque;
    private javax.swing.JLabel titulo;
    private javax.swing.JTextField txtProduto;
    private javax.swing.JLabel verificarEstoque;
    // End of variables declaration//GEN-END:variables
}
