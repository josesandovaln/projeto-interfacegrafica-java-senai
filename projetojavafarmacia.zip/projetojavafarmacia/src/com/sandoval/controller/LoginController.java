/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sandoval.controller;


import com.sandoval.connection.ConnectionFactory;
import com.sandoval.login.TelaLogin;
import com.sandoval.main.Main;
import com.sandoval.model.beans.Cadastro;
import com.sandoval.model.beans.LoginUsuario;
import com.sandoval.model.dao.CadastroDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Sandoval
 */
public class LoginController {
    
    private TelaLogin login;

    public LoginController(TelaLogin login) {
        this.login = login;
        
    }

    public void autenticar() throws SQLException {
        String usuario = login.getTxtUsuario().getText();
        String senha = login.getTxtSenha().getText();
        
        LoginUsuario loginUsuario = new LoginUsuario(usuario, senha);
        Cadastro cadastro = new Cadastro(usuario, senha);
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        CadastroDao cadastroUsuario = new CadastroDao(con);
        
        
        boolean existe = cadastroUsuario.existeUsuario(loginUsuario, cadastro);
        
        if(existe) {
            Main operacoes = new Main();
            operacoes.setVisible(true);
            javax.swing.JOptionPane.showMessageDialog(null, "Login do Vendedor: \nUsuario: " + login.getTxtUsuario().getText(), "LOGIN", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Usuario ou senha invalidos");
        }
        
        
        
    }
    
    
    
}
